import Foundation

var array: [Int] = []
var evenNumbers: [Int] = []
var notEvenNumbers: [Int] = []

func generateArrayWithRandomNumbers(size: Int) -> [Int] {
    var array: [Int] = Array(repeating: 0, count: size)
    
    for index in 0..<size {
        array[index] = Int.random(in: 0..<size)
    }
    
    return array
}

func partition(){
    for index in 0...array.count - 1{
        if array[index] % 2 == 0{
            evenNumbers.append(array[index])
        } else{
            notEvenNumbers.append(array[index])
        }
    }
}

array = generateArrayWithRandomNumbers(size: 50)
partition()
array = evenNumbers.sorted(by: { $0 < $1 } )
array = array + notEvenNumbers.sorted(by: { $0 > $1 })

print(array)

